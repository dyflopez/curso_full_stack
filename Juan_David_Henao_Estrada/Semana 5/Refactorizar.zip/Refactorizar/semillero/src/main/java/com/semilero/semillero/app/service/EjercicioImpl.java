package com.semilero.semillero.app.service;

import org.springframework.stereotype.Service;

@Service
public class EjercicioImpl implements IEjercicio {

    @Override
    public String encriptarPalabra(String palabra) {

        if (palabra.length() > 2) {
            String mensaje = "Palabra encriptada: " + palabra.charAt(0);

            for (int i = 1; i < palabra.length() - 1; i++) {

                mensaje = mensaje + '*';

            }
            int posicion = 0;

            posicion = palabra.length() - 1;
            mensaje = mensaje + palabra.charAt(posicion);

            return mensaje;

        } else {
            String mensaje = "NO SE ENCRIPTARA PALABRA CON MENOS DE DOS CARACTERES";
            return mensaje;
        }
    }

    @Override
    public String cifrarConCaracter(String mensaje, String caracter) {

        char vectorCaracteres[] = mensaje.toCharArray();
        StringBuilder cifrado = new StringBuilder();
        int ultimaPosicion = mensaje.length() - 1;

        if (mensaje.length() > 2) {
            cifrado.append(vectorCaracteres[0]);
            for (int i = 1; i < ultimaPosicion; i++) {
                cifrado.append(caracter);
            }
            cifrado.append(vectorCaracteres[ultimaPosicion]);
        } else {
            cifrado.append("La cadena tiene menos de dos digitos");
        }

        return cifrado.toString();
    }

    @Override
    public int sumarNumeros(int num1, int num2) {
        int resultado;
        resultado = num1 + num2;
        return resultado;
    }

    @Override
    public int multiplicarNumeros(int num1, int num2) {
        int resultado;
        resultado = num1 * num2;
        return resultado;
    }

}
/*

 public String cifrarConCaracter(String mensaje, String caracter) {

        char vectorCaracteres[] = mensaje.toCharArray();
StringBuilder cifrado = new StringBuilder();

        try {

            char vectorCaracteres[]=mensaje.toCharArray();


            int ultimaPosicion = mensaje.length()-1;

            if(mensaje.length()>2){
                cifrado.append(vectorCaracteres[0]);
                for(int i =1 ; i<ultimaPosicion;i++){
                    cifrado.append("*");
                }
                cifrado.append(vectorCaracteres[ultimaPosicion]);
            }else{
                cifrado.append("La cadena tiene menos de dos digitos");
            }

        }catch (Exception e){
            cifrado.append("Error en EjercicioImpl.cifrarMensaje ")
                    .append("la variable ingresa es : mensaje=> ")
                    .append(mensaje)
                    .append(" La trasa es ")
                    .append(e.toString());
        }finally {
            System.out.printf("Se ejecuto EjercicioImpl.cifrarMensaje");
        }


        return cifrado.toString();
    }
 */