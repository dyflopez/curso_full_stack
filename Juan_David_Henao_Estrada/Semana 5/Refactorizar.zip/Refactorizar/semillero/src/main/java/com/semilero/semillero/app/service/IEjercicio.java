package com.semilero.semillero.app.service;

public interface IEjercicio {


    public String encriptarPalabra(String palabra);

    public String cifrarConCaracter(String mensaje, String caracter);

    public int sumarNumeros(int num1, int num2);

    public int multiplicarNumeros(int num1, int num2);
}
