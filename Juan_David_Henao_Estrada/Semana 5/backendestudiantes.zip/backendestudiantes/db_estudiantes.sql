CREATE DATABASE institucion;

USE institucion;


INSERT INTO estudiante 
(id, nombre, apellido, correo) 
VALUES 
(NULL, 'Juan David', 'Henao Estrada', 'juan@gmail.com'), 
(NULL, 'Jairo', 'Hernandez', 'jairo@gmail.com'),
(NULL,'Jaime', 'Tapias', 'jaime@gmail.com'), 
(NULL,'Jorge', 'Gonzalez','jorge@gmail.com'),
(NULL,'Joaquin', 'Bedoya', 'joaquin@gmail.com'), 

(NULL,'Jose', 'Juarez','jose@gmsil.com'), 
(NULL,'Jesus', 'Alvarez','jesus@gmail.com'), 
(NULL,'Jasson','jimenez','jasson@gmail.com'), 
(NULL,'Anibal', 'Gutierrez', 'anibal@gmail.com'), 
(NULL,'Arnulfo', 'Benavides', 'arnu@gmail.com'), 

(NULL,'Angela', 'Figueroa', 'angela@gmail.com'), 
(NULL,'Alberto', 'Puerta', 'alberto@gmail.com'), 
(NULL,'Ana', 'Villegas', 'ana@gmail.com'), 
(NULL,'Bernardo', 'Benjumea', 'bernardo@gmail.com'),
(NULL,'Byron', 'Osa', 'byron@gmail.com'), 

(NULL, 'Carlos', 'Salazar', 'carlos@gmail.com'), 
(NULL, 'Cristal', 'Fince', 'cristal@gmail.com'), 
(NULL, 'Clara', 'correa',  'clara@gmail.com'), 
(NULL, 'Corinne', 'Casas', 'corinne@gmail.com'), 
(NULL, 'Crisanto', 'Vargas', 'crisanto@gmail.com'),
 
(NULL, 'Camilo', 'Saldarriaga', 'camilo@gmail.com'), 
(NULL, 'Diego', 'jimenez', 'diego@gmail.com'), 
(NULL, 'Damian', 'Restrepo', 'damian@gmail.com'), 
(NULL, 'Daniel', 'Florez', 'daniel@gmail.com'), 
(NULL, 'Emilio', 'Piedrahita', 'emilio@gmail.com'), 
(NULL, 'Edison', 'Suarez', 'edison@gmail.com');



