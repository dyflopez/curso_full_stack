package com.semillero.estudiantes.app.entity.repository;

import com.semillero.estudiantes.app.entity.EstudianteEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IEstudianteRepository extends JpaRepository<EstudianteEntity, Long> {


}
