package com.semillero.estudiantes.app.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Entity
@Table(name = "estudiante")
@AllArgsConstructor
@NoArgsConstructor

public class EstudianteEntity implements Serializable {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private long id;

    private String nombre;

    private String apellido;

    private String correo;

}
