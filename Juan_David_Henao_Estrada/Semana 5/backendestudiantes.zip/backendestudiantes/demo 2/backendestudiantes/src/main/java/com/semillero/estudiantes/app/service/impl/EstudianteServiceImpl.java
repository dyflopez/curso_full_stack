package com.semillero.estudiantes.app.service.impl;

import com.semillero.estudiantes.app.entity.repository.IEstudianteRepository;
import com.semillero.estudiantes.app.service.IEstudianteService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class EstudianteServiceImpl implements IEstudianteService {

    //Inyeccion de dependencias
    private final IEstudianteRepository iEstudianteRepository;

    public EstudianteServiceImpl(IEstudianteRepository iEstudianteRepository) {
        this.iEstudianteRepository = iEstudianteRepository;
    }

    @Override
    public ResponseEntity listarEstudiantes() {

        return ResponseEntity.ok(iEstudianteRepository.findAll());
    }

}
