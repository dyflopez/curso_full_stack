package com.semillero.estudiantes.app.service;

import org.springframework.http.ResponseEntity;

public interface IEstudianteService {
    ResponseEntity listarEstudiantes();

}
