package com.semillero.estudiantes.app.controller;

import com.semillero.estudiantes.app.service.IEstudianteService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController

@RequestMapping("/estudiante")
public class EstudianteController {

    //inyeccion de dependencias
    private final IEstudianteService iEstudianteService;

    public EstudianteController(IEstudianteService iEstudianteService) {
        this.iEstudianteService = iEstudianteService;
    }

    @GetMapping("/")
    public ResponseEntity getAllEstudiantes() {

        return iEstudianteService.listarEstudiantes();
    }

}
