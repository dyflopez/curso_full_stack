package co.com.semillero.semana3.examen.Utilities;

import co.com.semillero.semana3.examen.supermercado.GestionarSupermercado;
import co.com.semillero.semana3.examen.transferenciaObjeto.Producto;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Utilities {

    public static void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
    public static String capturarTexto() {

        Scanner t = new Scanner(System.in);
        String texto=" ";

        try {
            texto = t.next();
        }catch (Exception e){
            Utilities.mostrarMensaje("error al capturar texto");
        }finally {
           // Utilities.mostrarMensaje("Producto ingresado");
        }
        return texto;
    }

    public static int capturarEntero() {

        Scanner t = new Scanner(System.in);
        int numero = 0;

        try {
            numero = t.nextInt();
        } catch (Exception e) {
            Utilities.mostrarMensaje("Error en el metodo capturarEntero " + e.getMessage());
        } finally {
           // Utilities.mostrarMensaje("continue");
        }
        return numero;
    }
    public static double capturarDecimal() {

        Scanner t = new Scanner(System.in);
        double numero = 0;

        try {
            numero = t.nextDouble();
        } catch (Exception e) {
            Utilities.mostrarMensaje("ERROR AL INGRESAR CIFRA " + e.toString());
        } finally {
           // Utilities.mostrarMensaje("Dato ingresado");
        }
        return numero;
    }


/*
                bw.write(String.valueOf(productos));
                bw.close();

            }catch (IOException e) {
                System.err.println("no se ha podido crear el arrchivo");
            }
*/

}



