import co.com.semillero.semana3.examen.Utilities.Utilities;
import co.com.semillero.semana3.examen.supermercado.GestionarSupermercado;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {


        GestionarSupermercado gm =new GestionarSupermercado();
        Utilities ut =new Utilities();


        gm.menu();


    }
}