package co.com.semillero.semana3.examen.supermercado;

import co.com.semillero.semana3.examen.Utilities.Utilities;
import co.com.semillero.semana3.examen.transferenciaObjeto.Producto;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GestionarSupermercado {

    List<Producto> listaProductos = new ArrayList<>();

    public void agregarProductos() {

        Producto producto = new Producto();
        String nombre;
        double precio;
        String marca;

        Utilities.mostrarMensaje("Ingrese nombre del producto");
        nombre = Utilities.capturarTexto();

        Utilities.mostrarMensaje("Ingrese precio ");
        precio = Utilities.capturarDecimal();

        Utilities.mostrarMensaje("Ingrese marca ");
        marca = Utilities.capturarTexto();

        producto = new Producto(nombre, precio, marca);
        listaProductos.add(producto);
    }
    public void listarProductos() {

        for (Producto producto : listaProductos) {
            Utilities.mostrarMensaje(producto.toString() );
        }
    }
    public void elminarProductos() {

        int eliminar;
        Utilities.mostrarMensaje("Cantidad de productos: " + listaProductos.size());

        Utilities.mostrarMensaje("Para eliminar digite 0 siendo el primer producto de "+ listaProductos.size());
        eliminar = Utilities.capturarEntero();

        if(eliminar >= listaProductos.size()){
            System.out.println("Error en cantidad seleccionada");
        }else{
            listaProductos.remove(eliminar);
            System.out.println("Prodcuto removido");
        }

    }
    public void guardarListaEnArchivo() throws IOException {

        String path="C:\\Users\\jhenaoes\\Downloads\\FULLSTACK\\Semana 3\\Actividad 12 examenArray\\archivoLista.txt";

        File f = new File(path);

        try {
            if (!f.exists()){
                f.createNewFile();
            }
            FileWriter fw = new FileWriter(f);
            BufferedWriter bw = new BufferedWriter(fw);

            bw.write(String.valueOf(listaProductos));
            bw.close();

            Utilities.mostrarMensaje("Lista Guardada en Archivo");

        } catch (Exception e) {
            System.out.println("SUCEDIO UN ERROR " + e);

        }
    }
    public void leerArchivo() {

        File archivo;
        FileReader fr;
        BufferedReader br;

        try{
            archivo =new File("C:\\Users\\jhenaoes\\Downloads\\FULLSTACK\\Semana 3\\Actividad 12 examenArray\\archivoLista.txt");
            fr=new FileReader(archivo);
            br=new BufferedReader(fr);
            String linea;
            while ((linea=br.readLine())!=null){
                System.out.println(linea);
            }
            br.close();
            fr.close();

        } catch (Exception e) {
            System.out.println("error "+ e);
        }
    }

    public void menu() throws IOException {
        Scanner t = new Scanner(System.in);

        int limite = 0;
        while (limite == 0) {
            System.out.println(" ===================================== ");
            System.out.println(" ========= MENU PRINCIPAL ============ ");
            System.out.println(" ===================================== ");
            System.out.println(" ======== \uD83D\uDED2 = MERCADO  = \uD83D\uDED2========= "); //🛒
            System.out.println("                 \uD83D\uDECD          "); // 🛍
            System.out.println(" 1 -  INGRESAR PRODUCTOS               ");
            System.out.println(" 2 -  LISTAR PRODUCTOS                 ");
            System.out.println(" 3 -  ELIMINAR PRODUCTO                ");
            System.out.println(" 4 -  GUARDAR LISTA EN ARCHIVO         ");
            System.out.println(" 5 -  LEER  LISTA DESDE ARCHIVO        ");
            System.out.println(" 6 -  SALIR                            ");
            System.out.println(" ===================================== ");


             int opcion = Utilities.capturarEntero();
           // int opcion = t.nextInt();

            switch (opcion) {

                case 1 -> agregarProductos();

                case 2 -> listarProductos();

                case 3 -> elminarProductos();

                case 4 -> guardarListaEnArchivo();

                case 5 -> leerArchivo();

                case 6 -> {
                    System.out.println("Fin");
                    limite = 1;
                }
            }
        }
    }
}


  /*
    public void FOR() {
    metodo 1
     for (int i = 0; i < listaProductos.size(); i++) {
            System.out.println(listaProductos.get(i));
        }
    metodo 2
        for (Producto producto : listaProductos) {
            Utilities.mostrarMensaje("" + producto);
            Utilities.mostrarMensaje("Cantidad productos ingresados= " + producto.toString());
    metodo 3
        listaProductos.foreach ((producto)->{
        sout  (producto);
        });
     */
