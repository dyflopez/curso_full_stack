package com.empresa.empresa.app.service.impl;


import com.empresa.empresa.app.entity.UsuarioEntity;
import com.empresa.empresa.app.repository.IUsuarioRepository;
import com.empresa.empresa.app.service.IUsuarioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class UsuarioImpl implements IUsuarioService {

    private final IUsuarioRepository iUsuarioRepository;

    public UsuarioImpl(IUsuarioRepository iUsuarioRepository) {
        this.iUsuarioRepository = iUsuarioRepository;
    }

    @Override
    public ResponseEntity getUsuarioList() {
        var listaUsuario = iUsuarioRepository.findAll();

        return ResponseEntity.status(HttpStatus.OK).body(listaUsuario);
    }

    @Override
    public ResponseEntity postGuardarNuevoUsuario(UsuarioEntity usuarioEntity) {

        iUsuarioRepository.save(usuarioEntity);
        return ResponseEntity.status(HttpStatus.CREATED).body("Se creo usuario \uD83D\uDC64")	;
    }

    @Override
    public ResponseEntity deletePorId(long id) {
        iUsuarioRepository.deleteById(id);
        return ResponseEntity.status(HttpStatus.CREATED).body("Se elimionó usuario \uD83D\uDEAE");
    }

     @Override
    public ResponseEntity put(UsuarioEntity usuarioEntity) {
     var usuario = iUsuarioRepository.findById(usuarioEntity.id);
     if(usuario.isEmpty())

        return ResponseEntity.status(HttpStatus.CREATED).body("Usuario no existe \uD83D\uDEAB");

         iUsuarioRepository.save(usuarioEntity);

         return ResponseEntity.status(HttpStatus.CREATED).body("Se actualizó usuario \uD83D\uDD03");
    }

}
