package com.empresa.empresa.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name ="usuario")
public class UsuarioEntity {


    @Id
    @Column(name = "id_usuario")
    //@GeneratedValue(strategy = GenerationType.IDENTITY)

    public long id;
    public String nombre;
    public String apellido;
    public String email;




}
