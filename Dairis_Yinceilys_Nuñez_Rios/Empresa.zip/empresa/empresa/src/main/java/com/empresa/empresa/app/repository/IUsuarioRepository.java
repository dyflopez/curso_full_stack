package com.empresa.empresa.app.repository;

import com.empresa.empresa.app.entity.UsuarioEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IUsuarioRepository extends JpaRepository <UsuarioEntity, Long> {

}
