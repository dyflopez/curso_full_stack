package com.empresa.empresa.app.controller;

import com.empresa.empresa.app.service.IUsuarioService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/empresa")
public class EjemploController {


   // @GetMapping
   // public ResponseEntity getTest(){

   //     return IUsuarioService.getUsuarioList() ;
  //  }
}
