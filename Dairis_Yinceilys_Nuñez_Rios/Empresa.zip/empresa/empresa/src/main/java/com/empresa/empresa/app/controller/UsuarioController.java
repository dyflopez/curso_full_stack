package com.empresa.empresa.app.controller;


import com.empresa.empresa.app.entity.UsuarioEntity;
import com.empresa.empresa.app.service.IUsuarioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;
//import java.util.List;

@RestController
@RequestMapping("/usuario")
public class UsuarioController {

    private final IUsuarioService iUsuarioService;

    public UsuarioController(IUsuarioService iUsuarioService) {

        this.iUsuarioService = iUsuarioService;
    }


    @GetMapping
    public ResponseEntity getListUsuario() {

        return ResponseEntity.status(HttpStatus.OK).body(iUsuarioService.getUsuarioList());

    }

    @PostMapping
    public ResponseEntity postGuardar(@RequestBody UsuarioEntity usuarioEntity) {
        return iUsuarioService.postGuardarNuevoUsuario(usuarioEntity);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity deleteUsuario(@PathVariable("id") long id) {

        return iUsuarioService.deletePorId(id);
    }

    @PutMapping
    public ResponseEntity putUsuario(@RequestBody UsuarioEntity usuarioEntity) {

           return iUsuarioService.put(usuarioEntity);
       }



}
