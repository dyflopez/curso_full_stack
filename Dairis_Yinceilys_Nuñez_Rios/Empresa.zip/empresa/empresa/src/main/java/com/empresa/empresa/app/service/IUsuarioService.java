package com.empresa.empresa.app.service;

import com.empresa.empresa.app.entity.UsuarioEntity;
import org.springframework.http.ResponseEntity;

public interface IUsuarioService {

    ResponseEntity getUsuarioList();

    ResponseEntity postGuardarNuevoUsuario(UsuarioEntity usuarioEntity);

    ResponseEntity deletePorId(long id);

    ResponseEntity put(UsuarioEntity usuarioEntity);

}
