package com.semillero.semillero.appController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.websocket.server.PathParam;

@RestController
@RequestMapping("/ejemplo")

public class LetrasController {


    @GetMapping("/mensaje")
    public String letras(@PathParam("letra") String letras){

        //String letra = mensaje;
        int palabraFinal = 0;
        palabraFinal = letras.length() -1;

        String mensajeRetorno = null;
        if (letras.length() > 2) {
            mensajeRetorno = "" + letras.charAt(0);

            for (int i = 1; i < letras.length() - 1; i++) {

                    mensajeRetorno = mensajeRetorno + '*';

            }

            mensajeRetorno = mensajeRetorno + letras.charAt(palabraFinal);

        } else {
            mensajeRetorno = "no compila";

        }
        return mensajeRetorno;

    }

}

