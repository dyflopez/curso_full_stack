/*package com.semillero.semillero.appController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.websocket.server.PathParam;
import java.util.Scanner;

@RestController
@RequestMapping("/ejemplo")
public class NumerosController {

    @GetMapping("/proyecto")
    public static String Numeros(@PathParam("numero") String numeros){

        String mensaje = "123456789";
        System.out.println(numeros.charAt(0));
        for (int i = 0; i < numeros.length() - 1; i++){
            if (Character.isLetter((numeros.charAt(i)))) {
                System.out.println('*');
            }
        }

        mensaje = mensaje + numeros;
        System.out.println(numeros);
        return numeros;
    }

    public static int capturarEntero(){

        int numero;

        Scanner scanner = new Scanner(System.in);

        numero = scanner.nextInt();

        return  numero;
    }

}*/





