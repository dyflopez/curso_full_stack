package com.semillero.semillero;

//import com.semillero.semillero.appController.NumerosController;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SemilleroApplication {

	public static void main(String[] args) {

		SpringApplication.run(SemilleroApplication.class, args);

		//NumerosController.Numeros("");
		//LetrasController l = new LetrasController();
		//EjemploController ec = new EjemploController();
		//ec.Numeros("1*******9");
		//l.letras("");
	}
}
