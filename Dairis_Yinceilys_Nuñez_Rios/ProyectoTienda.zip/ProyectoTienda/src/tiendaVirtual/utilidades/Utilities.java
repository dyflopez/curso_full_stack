package tiendaVirtual.utilidades;
import tiendaVirtual.supermercado.GestionarSupermercado;
import tiendaVirtual.dto.Producto;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Utilities {
    public static void mostrarMensaje(String mensaje) {

        System.out.println(mensaje);
    }

    public static String capturarString() {

        String cadena = "";
        Scanner sc = new Scanner(System.in);
       // cadena = sc.next();
        try {
            cadena = sc.next();
        }catch (Exception e){
            Utilities.mostrarMensaje("error al capturar texto");

        }

        return cadena;
    }
        public static int capturarEntero() {

        Scanner scanner = new Scanner(System.in);
            int numero = 0;

        try {
            numero = scanner.nextInt();
        } catch (Exception e) {
            Utilities.mostrarMensaje("Error al capturarEntero() " + e.getMessage());
        } finally {
            Utilities.mostrarMensaje("Salio del metodo capturarEntero()");
        }

        return numero;
    }

    public static double capturarDouble() {

        double numero = 0.0;
        Scanner scanner = new Scanner(System.in);

        try {
            numero = scanner.nextDouble();
        } catch (Exception e) {
            Utilities.mostrarMensaje("Opp! tienes un error() " + e.toString());
        } finally {
            Utilities.mostrarMensaje("Salio del metodo capturarDouble()");
        }

        return numero;

    }

}
