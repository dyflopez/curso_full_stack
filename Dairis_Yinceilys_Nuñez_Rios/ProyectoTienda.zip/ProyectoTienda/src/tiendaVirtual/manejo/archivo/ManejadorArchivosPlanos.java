package tiendaVirtual.manejo.archivo;

public class ManejadorArchivosPlanos {
}
