package tiendaVirtual.supermercado;
import tiendaVirtual.dto.Producto;
import tiendaVirtual.utilidades.Utilities;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GestionarSupermercado {

    private List<Producto> productoList = new ArrayList<>();

    public void ingresarProducto() {

        Producto producto = new Producto();
        String nombre;
        double precio;
        String marca;

        Utilities.mostrarMensaje("Ingresa nombre del producto");
        nombre = Utilities.capturarString();

        Utilities.mostrarMensaje("Ingresa precio del producto");
        precio = Utilities.capturarDouble();

        Utilities.mostrarMensaje("Ingresa la marca del producto");
        marca = Utilities.capturarString();

        producto = new Producto(nombre, precio, marca);
        productoList.add(producto);

    }

    public void consultarProducto() {
        if(productoList.isEmpty()) {
            Utilities.mostrarMensaje("No existen productos, por favor seleccione la opcion ingresar producto (1)");
            return;
        }
        Utilities.mostrarMensaje("Ingresa nombre del producto");
        String nombre = Utilities.capturarString();
        for (Producto producto : productoList) {
            if(producto.getNombre().toLowerCase().contains(nombre.toLowerCase())){
                Utilities.mostrarMensaje(producto.toString());

            }
        }
    }

    public void elimicarProducto() {
        int eliminar;
        Utilities.mostrarMensaje("Cantidad de productos: " + productoList.size());

        Utilities.mostrarMensaje("Cuantos productos desea eliminar " + productoList.size());
        eliminar = Utilities.capturarEntero();

        if (eliminar >= productoList.size()) {
            System.out.println("Error en cantidad seleccionada");
        } else {
            productoList.remove(eliminar);
            System.out.println("Prodcuto removido");
        }
    }

    public void guardarProducto() throws IOException {

        String path = "C:\\Users\\dnunezri\\Downloads\\Git Dairis\\curso_full_stack\\Dairis_Yinceilys_Nuñez_Rios\\listaArchivo.txt";

        File f = new File(path);

        try {
            if (!f.exists()) {
                f.createNewFile();
            }
            FileWriter fw = new FileWriter(f);
            BufferedWriter bw = new BufferedWriter(fw);

            bw.write(String.valueOf(productoList));
            bw.close();

            Utilities.mostrarMensaje("Lista Guardada con exito ");

        } catch (Exception e) {
            System.out.println("opp! tienes un error " + e);

        }
    }

    public void cargarArchivo() {

        File archivo;
        FileReader fr;
        BufferedReader br;

        try {
            archivo = new File("C:\\Users\\dnunezri\\Downloads\\Git Dairis\\curso_full_stack\\Dairis_Yinceilys_Nuñez_Rios\\listaArchivo.txt");
            Scanner obj = new Scanner(archivo);
            while (obj.hasNextLine()){
                System.out.println(obj.nextLine());
            }
            //fr = new FileReader(archivo);
          //  br = new BufferedReader(fr);
         //   String linea;
         //   while ((linea = br.readLine()) != null) {
        //        System.out.println(linea);
        //    }
         //   br.close();
         //   fr.close();

        } catch (Exception e) {
            System.out.println("error " + e);
        }
    }

    public void menu() throws IOException {
        Scanner datos = new Scanner(System.in);

        int limite = 0;
        while (limite == 0) {
            System.out.println("Bienvenido a su tienda virtual \uD83D\uDECD");
            System.out.println("--------------------------");
            System.out.println("     MENU DE COMPRA \uD83D\uDED2");
            System.out.println("--------------------------");
            System.out.println("| 1. Ingresar Producto   |");
            System.out.println("| 2. Consultar Producto  |");
            System.out.println("| 3. Eliminar Producto   |");
            System.out.println("| 4. Guardar Producto    |");
            System.out.println("| 5. Cargar Archivo      |");
            System.out.println("| 6. Salir del Menu      |");
            System.out.println("--------------------------");

            int option = datos.nextInt();


            switch (option) {

                case 1 -> ingresarProducto();

                case 2 -> consultarProducto();

                case 3 -> elimicarProducto();

                case 4 -> guardarProducto();

                case 5 -> cargarArchivo();

                case 6 -> {
                    System.out.println("Adios");
                    limite = 1;

                }
            }
        }


        //public void mostrarCantidadDeProductos() {
           Utilities.mostrarMensaje("la cantidad de productos en la tienda es :" + productoList.size());
      //  }
      //  public void imprimirProdutosForEach () {
            for (Producto producto : productoList) {
                Utilities.mostrarMensaje(producto.toString());
            }
        }
    }


