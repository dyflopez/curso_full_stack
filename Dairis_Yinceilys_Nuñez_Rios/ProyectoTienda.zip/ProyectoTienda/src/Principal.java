import tiendaVirtual.supermercado.GestionarSupermercado;
import tiendaVirtual.utilidades.Utilities;

import java.io.IOException;

public class Principal {
    public static void main(String[] args) throws IOException {

        GestionarSupermercado gs =new GestionarSupermercado();
        gs.menu();


        // ManejadorArchivosPlanos archivosPlanos = new ManejadorArchivosPlanos();
        // Ejecutor ejecutar = new Ejecutor();
        //  ejecutar.ejecutar();


        //archivosPlanos.escribirArchivoPlano();

            }
        }
