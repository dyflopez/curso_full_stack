package com.semilero.semillero.app.service;

import org.springframework.stereotype.Service;

@Service
public class EjercicioImpl implements IEjercicio {

    @Override
    public String cifrarMensaje(String mensaje) {

        StringBuilder cifrado = new StringBuilder();

        try {

            char vectorCaracteres[] = mensaje.toCharArray();


            int ultimaPosicion = mensaje.length() - 1;

            if (mensaje.length() > 2) {
                cifrado.append(vectorCaracteres[0]);
                for (int i = 1; i < ultimaPosicion; i++) {
                    cifrado.append("*");
                }
                cifrado.append(vectorCaracteres[ultimaPosicion]);
            } else {
                cifrado.append("La cadena debe ser mayor a  dos digitos");
            }

        } catch (Exception e) {
            cifrado.append("Error en EjercicioImpl.cifrarMensaje ")
                    .append("la variable ingresa es : mensaje=> ")
                    .append(mensaje)
                    .append(" La trasa es ")
                    .append(e.toString());
        } finally {
            System.out.printf("Se ejecuto EjercicioImpl.cifrarMensaje");
        }


        return cifrado.toString();
    }

    @Override
    public String cifrarConCaracter(String mensaje, String caracter) {

        char vectorCaracteres[] = mensaje.toCharArray();
        StringBuilder cifrado = new StringBuilder();
        int ultimaPosicion = mensaje.length() - 1;

        if (mensaje.length() > 2) {
            cifrado.append(vectorCaracteres[0]);
            for (int i = 1; i < ultimaPosicion; i++) {
                cifrado.append(caracter);
            }
            cifrado.append(vectorCaracteres[ultimaPosicion]);
        } else {
            cifrado.append("La cadena debe ser mayor a dos digitos");
        }

        return cifrado.toString();
    }

    @Override
    public int sumarCaracter(int dato1, int dato2) {

        int dato = 0;

        try {

            dato = (dato1 + dato2);

        } catch (Exception e) {
            System.out.println("falló la suma, intente con otro número");

        }
        return dato;
    }


    @Override
    public int numeroDeLetras(String palabra) {

        int contador = 0;
        for (int i = 0; i < palabra.length(); i++) {

            if (palabra.charAt(i) == 'a' || palabra.charAt(i) == 'A') {
                contador++;
                contador = contador + palabra.length();
            }
        }
        return contador;
    }
}
