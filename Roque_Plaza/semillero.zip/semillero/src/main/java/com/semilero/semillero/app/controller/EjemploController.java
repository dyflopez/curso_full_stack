package com.semilero.semillero.app.controller;

import com.semilero.semillero.app.service.IEjercicio;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.websocket.server.PathParam;

// localhost:8080/ejemplo/mensaje

@RestController
@RequestMapping("/ejercicio")
public class EjemploController {


    private final IEjercicio iEjercicio;

    public EjemploController(IEjercicio iEjercicio) {
        this.iEjercicio = iEjercicio;
    }


    /**
     * http://localhost:8080/ejemplo/mensaje/?nombrePersona=LOPEZ
     */
    @GetMapping("/cifrar")
    public String getMensaje(@PathParam("mensaje") String mensaje) {
        return iEjercicio.cifrarMensaje(mensaje);
    }

    @GetMapping("/cifrar/{caracter}")
    public String getCifrarMensajeConCaracterEspesifico(@PathParam("mensaje") String mensaje,
                                                        @PathVariable("caracter") String caracter) {
        return iEjercicio.cifrarConCaracter(mensaje, caracter);

    }

    @GetMapping("/valor")
    public int sumarCaracter(@PathParam("dato") int dato1,
                             @PathParam("caracter") int dato2) {
        return iEjercicio.sumarCaracter(dato1, dato2);
    }


     @GetMapping("/{mensaje}")
    public int numeroDeLetras(@PathParam("mensaje") String palabra){

    return iEjercicio.numeroDeLetras(palabra);

     }
}
