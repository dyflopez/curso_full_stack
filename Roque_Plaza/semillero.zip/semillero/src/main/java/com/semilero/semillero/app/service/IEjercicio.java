package com.semilero.semillero.app.service;

public interface IEjercicio {

     public String cifrarMensaje(String mensaje);

     public String cifrarConCaracter(String mensaje,String caracter);

     int sumarCaracter( int dato1, int dato2);

     int numeroDeLetras(String palabra);
}
