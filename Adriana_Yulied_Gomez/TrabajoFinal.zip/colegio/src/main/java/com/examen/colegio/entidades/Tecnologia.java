package com.examen.colegio.entidades;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "\"TBL_TECNOLOGIAS\"")
@NamedQuery(name = "Tecnologia.findAll", query = "SELECT t FROM Tecnologia t")
public class Tecnologia {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_tecnologia")
	private int idTecnologia;

	@Column(name = "nombre")
	private String nombre;

	@Column(name = "porcentaje_manejo")
	private double porcentajeManejo;

	@Column(name = "nivel_conocimiento")
	private double nivelConocimiento;

	@Column(name = "año_experiencia")
	private Integer añoExperiencia;

	public Tecnologia() {
		super();
	}

	public int getIdTecnologia() {
		return idTecnologia;
	}

	public void setIdTecnologia(int idTecnologia) {
		this.idTecnologia = idTecnologia;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPorcentajeManejo() {
		return porcentajeManejo;
	}

	public void setPorcentajeManejo(double porcentajeManejo) {
		this.porcentajeManejo = porcentajeManejo;
	}

	public double getNivelConocimiento() {
		return nivelConocimiento;
	}

	public void setNivelConocimiento(double nivelConocimiento) {
		this.nivelConocimiento = nivelConocimiento;
	}

	public Integer getAñoExperiencia() {
		return añoExperiencia;
	}

	public void setAñoExperiencia(Integer añoExperiencia) {
		this.añoExperiencia = añoExperiencia;
	}

	@Override
	public String toString() {
		return "Tecnologia [idTecnologia=" + idTecnologia + ", nombre=" + nombre + ", porcentajeManejo="
				+ porcentajeManejo + ", nivelConocimiento=" + nivelConocimiento + ", añoExperiencia=" + añoExperiencia
				+ "]";
	}


}