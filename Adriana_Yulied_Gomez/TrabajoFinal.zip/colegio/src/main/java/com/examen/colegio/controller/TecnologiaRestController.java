package com.examen.colegio.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examen.colegio.entidades.Tecnologia;
import com.examen.colegio.services.TecnologiaService;

@CrossOrigin(origins = "http://localhost:8081")

@RestController

@RequestMapping("/colegio")
public class TecnologiaRestController {
	@Autowired
	private TecnologiaService tecnologiaService;

	@GetMapping("/tecnologias")
	public List<Tecnologia> findAll() {
		// retornará todos los alumnos
		return tecnologiaService.findAll();
	}

	@GetMapping("/tecnologias/{idTecnologai}")
	public Tecnologia gettecnologia(@PathVariable int IdTecnologia) {
		Tecnologia tecnologia = tecnologiaService.findById(IdTecnologia);

		if (tecnologia == null) {
			throw new RuntimeException("Tecnologia id not found -" + IdTecnologia);
		}
		// retornará al usuario con id pasado en la url
		return tecnologia;

	}

	@PostMapping("/tecnologias")
	public Tecnologia addTecnologia(@RequestBody Tecnologia tecnologia) {
		tecnologia.setIdTecnologia(0);

		// Este metodo guardará al usuario enviado
		tecnologiaService.save(tecnologia);

		return tecnologia;

	}

	@PutMapping("/tecnologias/{idTecnologia}")
	public Tecnologia updateTecnologia(@RequestBody Tecnologia tecnologia, @PathVariable int idTecnologia) {
		List<Tecnologia> tecnologias = tecnologiaService.findAll();
		Tecnologia tecno = new Tecnologia();

		for (Tecnologia tecnologia1 : tecnologias) {
			tecno = tecnologia1;
			if (tecnologia1.getIdTecnologia() == idTecnologia) {
				tecno.setNombre(tecnologia.getNombre());
				tecno.setPorcentajeManejo(tecnologia.getPorcentajeManejo());
				tecno.setNivelConocimiento(tecnologia.getNivelConocimiento());
				tecno.setAñoExperiencia(tecnologia.getAñoExperiencia());

				tecnologiaService.save(tecno);
				break;
			}

		}
		return tecno;
	}

	@DeleteMapping("/tecnologias/{idTecnologia}")
	public String deteteTecnologia(@PathVariable int idTecnologia) {

		Tecnologia tecno = tecnologiaService.findById(idTecnologia);

		if (tecno == null) {
			throw new RuntimeException("Alumno id not found -" + idTecnologia);
		}

		tecnologiaService.deleteById(idTecnologia);

		// Esto método, recibira el id de un usuario por URL y se borrará de la bd.
		return "Deleted Tecnologia id - " + idTecnologia;

	}
}
