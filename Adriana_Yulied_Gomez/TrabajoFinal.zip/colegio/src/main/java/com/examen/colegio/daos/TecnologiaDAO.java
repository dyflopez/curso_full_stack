package com.examen.colegio.daos;

import java.util.List;

import com.examen.colegio.entidades.Tecnologia;

public interface TecnologiaDAO {
	
	public List<Tecnologia> findAll();

    public Tecnologia findById(int id);

    public void save(Tecnologia tecnologia);

    public void deleteById(int id_tecnologia);
    
}
