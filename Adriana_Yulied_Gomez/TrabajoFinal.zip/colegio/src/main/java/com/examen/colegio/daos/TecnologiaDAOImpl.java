package com.examen.colegio.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;

import com.examen.colegio.entidades.Tecnologia;

public class TecnologiaDAOImpl implements TecnologiaDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Tecnologia> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query theQuery = currentSession.createQuery("from Tecnologia", Tecnologia.class);

		List<Tecnologia> tecnologias = theQuery.getResultList();

		return tecnologias;
	}

	@Override
	public Tecnologia findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Tecnologia tecnologia = currentSession.get(Tecnologia.class, id);

		return tecnologia;
	}

	@Override
	public void save(Tecnologia tecnologia) {
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(tecnologia);

	}

	@Override
	public void deleteById(int id_tecnologia) {
		Session currentSession = entityManager.unwrap(Session.class);
		Query theQuery = currentSession.createQuery("delete from Tecnologia where id_tecnologia =:id_tecnologia");
		theQuery.setParameter("id_tecnologia", id_tecnologia);
	}

}
