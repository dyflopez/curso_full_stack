package com.examen.colegio.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.examen.colegio.daos.TecnologiaDAO;
import com.examen.colegio.entidades.Tecnologia;

@Service
public class TecnologiaServiceImpl implements TecnologiaService {

	@Autowired
	private TecnologiaDAO tecnologiaDAO;

	@Override
	@Transactional(readOnly = true)
	public List<Tecnologia> findAll() {
		List<Tecnologia> tecnologias = tecnologiaDAO.findAll();
		return tecnologias;
	}

	@Override
	@Transactional(readOnly = true)
	public Tecnologia findById(int id) {
		Tecnologia tecnologia = tecnologiaDAO.findById(id);
		return tecnologia;
	}

	@Override
	@Transactional
	public void save(Tecnologia tecnologia) {
		tecnologiaDAO.save(tecnologia);
	}

	@Override
	@Transactional
	public void deleteById(int id_tecnologia) {
		tecnologiaDAO.deleteById(id_tecnologia);
	}

}
