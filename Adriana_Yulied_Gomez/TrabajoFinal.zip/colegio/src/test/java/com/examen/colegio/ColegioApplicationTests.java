package com.examen.colegio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColegioApplicationTests {

	@Test
	void contextLoads() {
	}

}
