package com.trabajo.crudcontra.dao;

import java.util.List;
import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.trabajo.crudcontra.entity.Docentes;

@Repository
public class DocentesDAOImpl implements DocentesDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Docentes> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Docentes> theQuery = currentSession.createQuery("from Docentes order by idDocente asc", Docentes.class);

		List<Docentes> docentes = theQuery.getResultList();

		return docentes;
	}

	@Override
	public Docentes findById(int id_docente) {
		Session currentSession = entityManager.unwrap(Session.class);

		Docentes docentes = currentSession.get(Docentes.class, id_docente);

		return docentes;
	}

	@Override
	public void save(Docentes docentes) {

		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.saveOrUpdate(docentes);

	}

	@Override
	public void deleteById(int id_docente) {

		Session currentSession = entityManager.unwrap(Session.class);

		Query<Docentes> theQuery = currentSession.createQuery("delete from Docentes where id_docente =:id_docente");

		theQuery.setParameter("id_docente", id_docente);

		theQuery.executeUpdate();

	}

}
