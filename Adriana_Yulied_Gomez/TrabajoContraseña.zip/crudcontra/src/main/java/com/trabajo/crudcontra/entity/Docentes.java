package com.trabajo.crudcontra.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "\"TBL_DOCENTES\"")
public class Docentes {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "id_docente")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idDocente;

	@Column(name = "nombre")
	private String nombre;
	
	@Column(name = "usuario")
	private String usuario;
	
	@Column(name = "contrasena")
	private String contrasena;

	public Docentes() {
		super();
	}

	public int getIdDocente() {
		return idDocente;
	}

	public void setIdDocente(int idDocente) {
		this.idDocente = idDocente;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getContrasena() {
		return contrasena;
	}

	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}

	@Override
	public String toString() {
		return "Docentes →"+ "Id de Docente= " + idDocente + "Nombre= " + nombre + "Usuario= " + usuario + "Contraseña= "
				+ contrasena;
	}

}
