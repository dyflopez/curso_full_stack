package com.trabajo.crudcontra.dao;

import java.util.List;

import com.trabajo.crudcontra.entity.Docentes;



public interface DocentesDAO {
	
	public List<Docentes> findAll();

	public Docentes findById(int id_docente);

	public void save(Docentes docentes);

	public void deleteById(int id_docente);

}
