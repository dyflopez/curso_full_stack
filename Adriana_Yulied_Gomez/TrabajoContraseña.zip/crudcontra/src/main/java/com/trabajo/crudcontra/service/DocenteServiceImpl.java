package com.trabajo.crudcontra.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.trabajo.crudcontra.dao.DocentesDAO;
import com.trabajo.crudcontra.entity.Docentes;

@Repository
public class DocenteServiceImpl implements DocenteService{

	@Autowired
	private DocentesDAO docentesDAO;

	@Override
	@Transactional(readOnly = true)
	public List<Docentes> findAll() {
		List<Docentes> listDocentes = docentesDAO.findAll();
		return listDocentes;
	}

	@Override
	@Transactional(readOnly = true)
	public Docentes findById(int id_docente) {
		Docentes docentes = docentesDAO.findById(id_docente);
		return docentes;
	}

	@Override
	@Transactional
	public void save(Docentes docentes) {
		docentesDAO.save(docentes);
		
	}

	@Override
	@Transactional
	public void deleteById(int id_docente) {
		docentesDAO.deleteById(id_docente);
	}

}
