package com.trabajo.crudcontra.service;

import java.util.List;

import com.trabajo.crudcontra.entity.Docentes;


public interface DocenteService {

	public List<Docentes> findAll();

	public Docentes findById(int id_docente);

	public void save(Docentes docentes);

	public void deleteById(int id_docente);

}
