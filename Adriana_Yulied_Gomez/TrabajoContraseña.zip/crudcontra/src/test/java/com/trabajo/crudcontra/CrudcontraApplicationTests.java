package com.trabajo.crudcontra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudcontraApplicationTests {

	@Test
	void contextLoads() {
	}

}
