package entidy;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Service {
	public static List<Empleado> Empleados = new ArrayList<>();

	public static void registrarEmployed() {
		int numEmployed;
		do {

			Scanner teclado = new Scanner(System.in);

			System.out.println("Escriba el numero de empleado a registrar: ");
			numEmployed = teclado.nextInt();

		} while (numEmployed <= 0);

		for (int i = 0; i < numEmployed; i++) {

			Scanner empledo = new Scanner(System.in);

			Empleado newempleado = new Empleado("", 0);

			String nombre;
			System.out.println("Esbriba el Nombre: ");
			nombre = empledo.next();
			newempleado.setNombre(nombre);

			Integer salario;
			System.out.println("Escriba el salario mayor a 0: ");
			salario = empledo.nextInt();
			newempleado.setSalario(salario);

			Empleados.add(newempleado);

		}
	}

	public static void showEmployed() {
		System.out.println("Los empleados registrados son: ");
		for (Empleado i : Empleados) {
			
			System.out.println("El Nombre es → " + i.getNombre());
			System.out.println("El Apellido es → " + i.getSalario());
			System.out.println("\n");
		}

	}

	public static void showSalary() {
		System.out.println("Los empleado con un salario menor a un millon son: ");
		for (Empleado i : Empleados) {
			
			if (i.getSalario() < 1000000) {
				
				System.out.println(" -*- -" + i.getNombre());
				System.out.println("\n");

			}

		}
	}
}
