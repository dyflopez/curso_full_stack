package main;

import entidy.Empleado;
import entidy.Service;

public class main {
	public static void main(String[] args) {
		Service.registrarEmployed();
		Service.showEmployed();
		Service.showSalary();
	}
}
