package com.semilero.semillero.app.service;

import org.springframework.stereotype.Service;

@Service
public class EjercicioImpl implements IEjercicio{

    @Override
    public String cifrarMensaje(String mensaje) {

        StringBuilder cifrado = new StringBuilder();

        try {

            char vectorCaracteres[]=mensaje.toCharArray();


            int ultimaPosicion = mensaje.length()-1;

            if(mensaje.length()>2){
                cifrado.append(vectorCaracteres[0]);
                for(int i =1 ; i<ultimaPosicion;i++){
                    cifrado.append("*");
                }
                cifrado.append(vectorCaracteres[ultimaPosicion]);
            }else{
                cifrado.append("La cadena tiene menos de dos digitos");
            }

        }catch (Exception e){
            cifrado.append("Error en EjercicioImpl.cifrarMensaje ")
                    .append("la variable ingresa es : mensaje=> ")
                    .append(mensaje)
                    .append(" La trasa es ")
                    .append(e.toString());
        }finally {
            System.out.printf("Se ejecuto EjercicioImpl.cifrarMensaje");
        }


        return cifrado.toString();
    }

    @Override
    public String cifrarConCaracter(String mensaje, String caracter) {

        char vectorCaracteres[]=mensaje.toCharArray();
        StringBuilder cifrado = new StringBuilder();
        int ultimaPosicion = mensaje.length()-1;

        if(mensaje.length()>2){
            cifrado.append(vectorCaracteres[0]);
            for(int i =1 ; i<ultimaPosicion;i++){
                cifrado.append(caracter);
            }
            cifrado.append(vectorCaracteres[ultimaPosicion]);
        }else{
            cifrado.append("La cadena tiene menos de dos digitos");
        }

        return cifrado.toString() ;
    }
    @Override
    public int suma(int calculo1, int calculo2) {
        int calculo_total = 0;
        try {

            calculo_total = calculo1 + calculo2;

            return calculo_total;
        }catch (Exception e){

        }
        return calculo_total;
    }

}
