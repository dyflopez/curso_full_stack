package com.semilero.semillero.app.service;

public interface IEjercicio {

     public String cifrarMensaje(String mensaje);

     public String cifrarConCaracter(String mensaje,String caracter);

     int suma(int calculo1, int calculo2);
}
