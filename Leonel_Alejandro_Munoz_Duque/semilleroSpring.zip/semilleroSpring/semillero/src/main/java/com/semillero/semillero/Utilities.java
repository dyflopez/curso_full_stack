package com.semillero.semillero;

import java.util.Scanner;

public class Utilities {

    public static void mostrarMensaje(String mensajeConsola) {

        System.out.println(mensajeConsola);

    }

    public static String capturarString() {


        String cadena;

        Scanner scanner = new Scanner(System.in);

        cadena = scanner.nextLine();

        return cadena;
    }

    public static int capturarEntero(){

        int numero;

        Scanner scanner = new Scanner(System.in);

        numero = scanner.nextInt();

        return  numero;
    }


}
