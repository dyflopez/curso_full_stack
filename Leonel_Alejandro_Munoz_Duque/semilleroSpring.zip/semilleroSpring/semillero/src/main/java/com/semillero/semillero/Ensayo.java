package com.semillero.semillero;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.websocket.server.PathParam;

@RequestMapping("/ejemplo")
@RestController

public class Ensayo {

    @GetMapping("/servicio")
    public static String servicioSpringBootCifrado(@PathParam("mensaje") String mensaje) {

        String contador = "";

        if (mensaje.length() > 2) {

            for (int i = 1; i < mensaje.length() - 1; i++) {

                contador += "*";


            }
            mensaje = (mensaje.charAt(0) + contador + mensaje.charAt((mensaje.length() - 1)));


        } else {
            mensaje = ("No se pudo cifrar tú frase, ingresa mas de dos caracteres");

        }
        return mensaje;

    }
}

