package co.com.ntt.semillero.fullstack.java.Mysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
