package co.com.ntt.semillero.fullstack.java.Mysql.service;

import co.com.ntt.semillero.fullstack.java.Mysql.entity.PersonaEntity;

import java.util.List;

public interface IPersonaImpl {

    List<PersonaEntity> getPersonaList();

}
