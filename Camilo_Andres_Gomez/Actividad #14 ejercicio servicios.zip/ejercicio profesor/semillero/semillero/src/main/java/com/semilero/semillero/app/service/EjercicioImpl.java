package com.semilero.semillero.app.service;

import org.springframework.stereotype.Service;

@Service
public class EjercicioImpl implements IEjercicio {

    @Override
    public String cifrarMensaje(String mensaje) {

        StringBuilder cifrado = new StringBuilder();

        char vectorCaracteres[] = mensaje.toCharArray();

        int ultimaPosicion = mensaje.length() - 1;

        if (mensaje.length() > 2) {
            cifrado.append(vectorCaracteres[0]);
            for (int i = 1; i < ultimaPosicion; i++) {
                cifrado.append("*");
            }
            cifrado.append(vectorCaracteres[ultimaPosicion]);
        } else {
            cifrado.append("La cadena tiene menos de dos digitos");
        }

        return cifrado.toString();
    }

    @Override
    public String cifrarConCaracter(String mensaje, String caracter) {

        char vectorCaracteres[] = mensaje.toCharArray();

        StringBuilder cifrado = new StringBuilder();

        int ultimaPosicion = mensaje.length() - 1;

        if (mensaje.length() > 2) {

            cifrado.append(vectorCaracteres[0]);
            for (int i = 1; i < ultimaPosicion; i++) {
                cifrado.append(caracter);
            }
            cifrado.append(vectorCaracteres[ultimaPosicion]);
        } else {
            cifrado.append("La cadena tiene menos de dos digitos");
        }

        return cifrado.toString();
    }

    @Override
    public int sumarDatos(int dato1, int dato2) {

        int resultado = 0;
        resultado = dato1 + dato2;

        return resultado;
    }

    @Override
    public String hello(String animal) {
        String res = "";
        if (animal.equals("1")) {
            res = "Leon";
        } else if (animal.equals("2")) {
            res = "Aguila";
        } else {
            res = "no se encuentra el animal";
        }
        return res;
    }


}




