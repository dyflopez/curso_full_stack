package com.semilero.semillero.app.service;

public interface IEjercicio {

     public String cifrarMensaje(String mensaje);

     public String cifrarConCaracter(String mensaje,String caracter);

     public int sumarDatos(int dato1, int dato2);

     public String hello(String animal);


}
