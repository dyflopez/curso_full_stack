package com.example.sumaSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SumaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SumaSpringApplication.class, args);
	}

}
