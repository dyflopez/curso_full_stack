package com.example.sumaSpring.service;

import org.springframework.stereotype.Service;

@Service
public class MetodoSumaImpl implements IMetodoSuma {


    public int sumaNumeros(int numero1, int numero2) {

        int resultado;

        resultado = numero1 + numero2;

        return resultado;

    }

    public int restaNumeros(int numero1, int numero2) {

        int resultado;

        resultado = numero1 - numero2;

        return resultado;

    }

    public int productoNumeros(int numero1, int numero2) {

        int resultado;

        resultado = numero1 * numero2;

        return resultado;

    }

    public int divisionNumeros(int numero1, int numero2) {

        int resultado2 = 0;

        try {

            resultado2 = numero1 / numero2;


        } catch (ArithmeticException e) {

        }

        return resultado2;

    }
}
