package com.example.sumaSpring.service;

public interface IMetodoSuma {

    public int sumaNumeros(int numero1, int numero2);

    public int restaNumeros(int numero1, int numero2);

    public int productoNumeros(int numero1, int numero2);

    public int divisionNumeros(int numero1, int numero2);

}
