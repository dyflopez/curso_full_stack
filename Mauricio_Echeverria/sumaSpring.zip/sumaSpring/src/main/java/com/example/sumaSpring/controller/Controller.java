package com.example.sumaSpring.controller;

import com.example.sumaSpring.service.IMetodoSuma;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.websocket.server.PathParam;

@RestController
@RequestMapping("/operaciones")
public class Controller {

    private final IMetodoSuma iMetodoSuma;

    public Controller(IMetodoSuma iMetodoSuma) {
        this.iMetodoSuma = iMetodoSuma;
    }

    @GetMapping("/suma")
    public int sumaNumeros(@PathParam("numero1") int numero1, @PathParam("numero2") int numero2) {
        return iMetodoSuma.sumaNumeros(numero1, numero2);
    }

    @GetMapping("/resta")
    public int restaNumeros(@PathParam("numero1") int numero1, @PathParam("numero2") int numero2) {
        return iMetodoSuma.restaNumeros(numero1, numero2);
    }

    @GetMapping("/multiplicacion")
    public int productoNumeros(@PathParam("numero1") int numero1, @PathParam("numero2") int numero2) {
        return iMetodoSuma.productoNumeros(numero1, numero2);
    }

    @GetMapping("/division")
    public int divisionNumeros(@PathParam("numero1") int numero1, @PathParam("numero2") int numero2) {
        return iMetodoSuma.divisionNumeros(numero1, numero2);
    }




}
